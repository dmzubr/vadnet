import pika
import yaml

# For DEBUG purpose
import sys
import numpy

numpy.set_printoptions(threshold=sys.maxsize)


class ServiceBus:
    """
    Rabbit MQ message receiver.
    """

    def __init__(self, host: str, port: int, user: str, password: str, exchange_name: str = 'easy_net_q_rpc'):
        self.__user = user
        self.__password = password
        self.__host = host
        self.__port = port
        self.__exchange_name = exchange_name
        self.__channel = None
        self.__response_callback = None
        self.__response_queue_name = None

    @classmethod
    def from_config_file(cls, config_file_path: str) -> 'ServiceBus':
        with open(config_file_path, 'r') as inf:
            config = yaml.safe_load(inf)

        return cls(user=config['user'], password=config['password'], host=config['host'], port=config['port'])

    def __on_request_handler(self, ch, method, props, body):

        response_body = self.__response_callback(body)
        ch.basic_publish(exchange='', routing_key=props.reply_to,
                         properties=pika.BasicProperties(correlation_id=props.correlation_id,
                                                         type=self.__response_queue_name), body=response_body)
        ch.basic_ack(delivery_tag=method.delivery_tag)

    def respond(self, request_queue_name: str, response_queue_name: str, request_handler_callback):
        while True:
            try:
                credentials = pika.PlainCredentials(self.__user, self.__password)
                parameters = pika.ConnectionParameters(host=self.__host, port=self.__port, credentials=credentials)
                connection = pika.BlockingConnection(parameters)

                self.__channel = connection.channel()
                self.__response_queue_name = response_queue_name
                self.__response_callback = request_handler_callback

                self.__channel.queue_declare(queue=request_queue_name, durable=True, exclusive=False, auto_delete=False)
                self.__channel.queue_bind(queue=request_queue_name, exchange=self.__exchange_name,
                                          routing_key=request_queue_name)
                self.__channel.basic_consume(queue=request_queue_name, on_message_callback=self.__on_request_handler)

                try:
                    self.__channel.start_consuming()
                except KeyboardInterrupt:
                    self.__channel.stop_consuming()
                    connection.close()
            except Exception as e:
                print(e)
                continue
