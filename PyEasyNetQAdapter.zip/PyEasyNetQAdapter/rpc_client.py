import uuid

import pika
import yaml


class ServiceBus:
    """
    Rabbit MQ message sender.
    """
    def __init__(self, host: str, port: int, user: str, password: str, exchange_name: str = 'easy_net_q_rpc'):

        self.__user = user
        self.__password = password
        self.__host = host
        self.__port = port
        self.__exchange_name = exchange_name

        credentials = pika.PlainCredentials(self.__user, self.__password)
        self.__parameters = pika.ConnectionParameters(host=self.__host, port=self.__port, credentials=credentials)
        self.__connection = pika.BlockingConnection(self.__parameters)
        self.__channel = self.__connection.channel()

    @classmethod
    def from_config_file(cls, config_file_path: str) -> 'ServiceBus':
        with open(config_file_path, 'r') as inf:
            config = yaml.safe_load(inf)

        return cls(user=config['user'], password=config['password'], host=config['host'], port=config['port'])

    def __on_response(self, ch, method, props, body):
        if self.corr_id == props.correlation_id:
            self.response = body

    def request(self, request_queue_name: str, response_queue_name: str, request_body):
        queue_create_result = self.__channel.queue_declare(queue=response_queue_name, exclusive=True)
        self.callback_queue = queue_create_result.method.queue

        self.__channel.basic_consume(queue=self.callback_queue, on_message_callback=self.__on_response, auto_ack=True)

        self.response = None
        self.corr_id = str(uuid.uuid4())
        self.__channel.basic_publish(exchange=self.__exchange_name, routing_key=request_queue_name,
                                     properties=pika.BasicProperties(reply_to=self.callback_queue,
                                                                     correlation_id=self.corr_id), body=request_body)
        while self.response is None:
            self.__connection.process_data_events()
        return self.response
