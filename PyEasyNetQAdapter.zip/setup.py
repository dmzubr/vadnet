from setuptools import setup

setup(name='PyEasyNetQAdapter',
      version='0.1',
      description='AMQP RPC client and server',
      url='http://github.com/example/',
      author='Shulev Artem',
      author_email='example@example.com',
      license='MIT',
      packages=['PyEasyNetQAdapter'],
      zip_safe=False)
